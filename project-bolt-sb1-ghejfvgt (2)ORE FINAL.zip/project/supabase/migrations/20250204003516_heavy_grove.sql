/*
  # Initial Schema Setup for SenPixel Studio

  1. Tables
    - users (extends auth.users)
    - bookings
    - gallery
    - blog_posts
    - testimonials

  2. Security
    - RLS policies for all tables
    - Public read access for gallery, blog_posts, testimonials
    - Authenticated access for bookings
*/

-- Users table extending auth.users
CREATE TABLE IF NOT EXISTS public.users (
  id uuid REFERENCES auth.users ON DELETE CASCADE,
  full_name text,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  PRIMARY KEY (id)
);

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Bookings table
CREATE TABLE IF NOT EXISTS public.bookings (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES public.users(id) ON DELETE CASCADE,
  service_type text CHECK (service_type IN ('photo', 'video', 'event')),
  date date NOT NULL,
  time time NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled')),
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- Gallery table
CREATE TABLE IF NOT EXISTS public.gallery (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  title text NOT NULL,
  description text,
  category text CHECK (category IN ('wedding', 'corporate', 'event', 'portrait')),
  image_url text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.gallery ENABLE ROW LEVEL SECURITY;

-- Blog posts table
CREATE TABLE IF NOT EXISTS public.blog_posts (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  title text NOT NULL,
  content text NOT NULL,
  image_url text,
  author uuid REFERENCES public.users(id),
  category text CHECK (category IN ('tips', 'news', 'behind-the-scenes')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;

-- Testimonials table
CREATE TABLE IF NOT EXISTS public.testimonials (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_name text NOT NULL,
  role text,
  content text NOT NULL,
  rating integer CHECK (rating >= 1 AND rating <= 5),
  image_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.testimonials ENABLE ROW LEVEL SECURITY;

-- RLS Policies

-- Users policies
CREATE POLICY "Users can view own profile"
  ON public.users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Bookings policies
CREATE POLICY "Users can view own bookings"
  ON public.bookings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own bookings"
  ON public.bookings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Gallery policies
CREATE POLICY "Public can view gallery"
  ON public.gallery
  FOR SELECT
  TO anon
  USING (true);

-- Blog posts policies
CREATE POLICY "Public can view blog posts"
  ON public.blog_posts
  FOR SELECT
  TO anon
  USING (true);

-- Testimonials policies
CREATE POLICY "Public can view testimonials"
  ON public.testimonials
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Authenticated users can create testimonials"
  ON public.testimonials
  FOR INSERT
  TO authenticated
  WITH CHECK (true);