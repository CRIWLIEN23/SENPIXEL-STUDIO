import React from 'react';

const Testimonials = () => {
  return (
    <section id="testimonials" className="py-20 bg-[#212121]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
          <span className="text-[#FFC107]">Témoignages</span> Clients
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <TestimonialCard 
            name="Marie Diop"
            role="Mariée"
            text="Une expérience incroyable ! Les photos de notre mariage sont magnifiques."
          />
          <TestimonialCard 
            name="Ousmane Sow"
            role="Directeur Marketing"
            text="Professionnalisme et créativité au rendez-vous. Exactement ce dont notre entreprise avait besoin."
          />
          <TestimonialCard 
            name="Fatou Ndiaye"
            role="Artiste"
            text="Un talent exceptionnel pour capturer l'essence de mon art. Je recommande vivement !"
          />
        </div>
      </div>
    </section>
  );
};

const TestimonialCard = ({ name, role, text }: { name: string, role: string, text: string }) => (
  <div className="bg-[#1a1a1a] p-6 rounded-lg">
    <p className="text-gray-300 mb-4 italic">&quot;{text}&quot;</p>
    <div>
      <p className="font-semibold text-[#FFC107]">{name}</p>
      <p className="text-gray-400 text-sm">{role}</p>
    </div>
  </div>
);

export default Testimonials;