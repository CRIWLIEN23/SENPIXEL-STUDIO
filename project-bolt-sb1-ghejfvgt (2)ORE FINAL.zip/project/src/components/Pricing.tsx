import React from 'react';
import { Camera, Video, Users, Building2 } from 'lucide-react';

const Pricing = () => {
  return (
    <section id="pricing" className="py-20 bg-[#1a1a1a]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
          <span className="text-[#FFC107]">Nos</span> Tarifs
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <PriceCard
            title="Photo"
            price="50.000"
            icon={<Camera className="w-12 h-12 text-[#FFC107]" />}
            features={[
              "Séance photo professionnelle",
              "10 photos retouchées",
              "Livraison express",
              "Format numérique HD"
            ]}
          />
          <PriceCard
            title="Vidéo"
            price="150.000"
            icon={<Video className="w-12 h-12 text-[#007BFF]" />}
            features={[
              "Tournage professionnel",
              "Montage vidéo",
              "Effets spéciaux",
              "Format 4K"
            ]}
            featured={true}
          />
          <PriceCard
            title="Événement"
            price="250.000"
            icon={<Users className="w-12 h-12 text-[#FF3D00]" />}
            features={[
              "Photos + Vidéos",
              "Équipe complète",
              "Album photo premium",
              "Montage personnalisé"
            ]}
          />
        </div>
      </div>
    </section>
  );
};

const PriceCard = ({ title, price, icon, features, featured = false }: {
  title: string;
  price: string;
  icon: React.ReactNode;
  features: string[];
  featured?: boolean;
}) => (
  <div className={`
    relative overflow-hidden rounded-2xl p-8
    ${featured ? 'bg-[#FFC107] transform scale-105' : 'bg-[#212121]'}
    transition-transform duration-300 hover:-translate-y-2
  `}>
    {featured && (
      <div className="absolute top-4 right-4">
        <span className="bg-[#FF3D00] text-white text-sm py-1 px-3 rounded-full">
          Populaire
        </span>
      </div>
    )}
    <div className="flex flex-col items-center">
      {icon}
      <h3 className={`text-2xl font-bold mt-4 ${featured ? 'text-[#212121]' : 'text-white'}`}>
        {title}
      </h3>
      <div className="mt-4 mb-6">
        <span className={`text-4xl font-bold ${featured ? 'text-[#212121]' : 'text-[#FFC107]'}`}>
          {price}
        </span>
        <span className={`text-sm ${featured ? 'text-[#212121]/80' : 'text-gray-400'}`}> FCFA</span>
      </div>
      <ul className="space-y-3">
        {features.map((feature, index) => (
          <li
            key={index}
            className={`flex items-center ${featured ? 'text-[#212121]' : 'text-gray-300'}`}
          >
            <span className="mr-2">✓</span>
            {feature}
          </li>
        ))}
      </ul>
      <button
        className={`
          mt-8 w-full py-3 px-6 rounded-full font-semibold transition-colors
          ${featured
            ? 'bg-[#212121] text-white hover:bg-[#313131]'
            : 'bg-[#FFC107] text-[#212121] hover:bg-[#e6ae06]'}
        `}
      >
        Réserver maintenant
      </button>
    </div>
  </div>
);

export default Pricing;