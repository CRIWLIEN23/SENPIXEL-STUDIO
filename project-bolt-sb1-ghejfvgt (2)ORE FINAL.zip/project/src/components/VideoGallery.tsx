import React, { useState } from 'react';
import { Play, Plus, X } from 'lucide-react';

interface Video {
  id: string;
  title: string;
  videoUrl: string;
  thumbnail: string;
  category: 'mariage' | 'evenement';
}

const VideoGallery = () => {
  const [videos, setVideos] = useState<Video[]>([
    {
      id: '1',
      title: 'Mariage traditionnel à Tambacounda',
      videoUrl: 'https://player.vimeo.com/external/459863667.sd.mp4?s=e9e6b9a3b266c0a4e4cbc53f2c93f8f2f5d09b00&profile_id=164&oauth2_token_id=57447761',
      thumbnail: 'https://images.unsplash.com/photo-1511795409834-432f7b1728f2',
      category: 'mariage'
    },
    {
      id: '2',
      title: 'Festival culturel de Tambacounda',
      videoUrl: 'https://player.vimeo.com/external/459863667.sd.mp4?s=e9e6b9a3b266c0a4e4cbc53f2c93f8f2f5d09b00&profile_id=164&oauth2_token_id=57447761',
      thumbnail: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30',
      category: 'evenement'
    }
  ]);

  const [showModal, setShowModal] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [newVideo, setNewVideo] = useState({
    title: '',
    videoUrl: '',
    thumbnail: '',
    category: 'mariage' as 'mariage' | 'evenement'
  });

  const handleAddVideo = (e: React.FormEvent) => {
    e.preventDefault();
    if (newVideo.title && newVideo.videoUrl) {
      setVideos([...videos, {
        id: Date.now().toString(),
        ...newVideo
      }]);
      setNewVideo({ title: '', videoUrl: '', thumbnail: '', category: 'mariage' });
      setShowModal(false);
    }
  };

  const playVideo = (video: Video) => {
    setSelectedVideo(video);
  };

  const mariageVideos = videos.filter(video => video.category === 'mariage');
  const evenementVideos = videos.filter(video => video.category === 'evenement');

  const VideoSection = ({ title, videos }: { title: string, videos: Video[] }) => (
    <div className="mb-16">
      <h3 className="text-2xl font-bold mb-8 text-white">
        <span className="text-[#FFC107]">{title}</span>
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {videos.map((video) => (
          <div
            key={video.id}
            className="group relative overflow-hidden rounded-lg cursor-pointer"
            onClick={() => playVideo(video)}
          >
            <img
              src={video.thumbnail || 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32'}
              alt={video.title}
              className="w-full h-64 object-cover transform transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <Play className="w-16 h-16 text-[#FFC107]" />
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
              <h3 className="text-white font-semibold">{video.title}</h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <section id="videos" className="py-20 bg-[#1a1a1a]">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold">
            <span className="text-[#FFC107]">Notre</span> Vidéothèque
          </h2>
          <button
            onClick={() => setShowModal(true)}
            className="bg-[#FFC107] text-[#212121] px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#e6ae06] transition-colors"
          >
            <Plus size={20} />
            Ajouter une vidéo
          </button>
        </div>

        <VideoSection title="Mariages" videos={mariageVideos} />
        <VideoSection title="Événements" videos={evenementVideos} />

        {/* Modal d'ajout de vidéo */}
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80">
            <div className="bg-[#212121] rounded-lg w-full max-w-md p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-semibold text-white">Ajouter une vidéo</h3>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <X size={24} />
                </button>
              </div>
              <form onSubmit={handleAddVideo} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">
                    Titre
                  </label>
                  <input
                    type="text"
                    value={newVideo.title}
                    onChange={(e) => setNewVideo({ ...newVideo, title: e.target.value })}
                    className="w-full p-2 bg-[#2a2a2a] rounded border border-gray-600 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">
                    URL de la vidéo
                  </label>
                  <input
                    type="url"
                    value={newVideo.videoUrl}
                    onChange={(e) => setNewVideo({ ...newVideo, videoUrl: e.target.value })}
                    className="w-full p-2 bg-[#2a2a2a] rounded border border-gray-600 text-white"
                    required
                    placeholder="https://example.com/video.mp4"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">
                    Catégorie
                  </label>
                  <select
                    value={newVideo.category}
                    onChange={(e) => setNewVideo({ ...newVideo, category: e.target.value as 'mariage' | 'evenement' })}
                    className="w-full p-2 bg-[#2a2a2a] rounded border border-gray-600 text-white"
                    required
                  >
                    <option value="mariage">Mariage</option>
                    <option value="evenement">Événement</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">
                    URL de la miniature (optionnel)
                  </label>
                  <input
                    type="url"
                    value={newVideo.thumbnail}
                    onChange={(e) => setNewVideo({ ...newVideo, thumbnail: e.target.value })}
                    className="w-full p-2 bg-[#2a2a2a] rounded border border-gray-600 text-white"
                    placeholder="https://example.com/thumbnail.jpg"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-[#FFC107] text-[#212121] font-semibold py-2 px-4 rounded hover:bg-[#e6ae06] transition-colors"
                >
                  Ajouter la vidéo
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Modal de lecture vidéo */}
        {selectedVideo && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95">
            <div className="bg-[#212121] rounded-lg w-full max-w-5xl">
              <div className="p-4 border-b border-gray-700 flex justify-between items-center">
                <h3 className="text-xl font-semibold text-white">{selectedVideo.title}</h3>
                <button
                  onClick={() => setSelectedVideo(null)}
                  className="text-gray-400 hover:text-white"
                >
                  <X size={24} />
                </button>
              </div>
              <div className="relative bg-black">
                <video
                  className="w-full"
                  controls
                  autoPlay
                  playsInline
                >
                  <source src={selectedVideo.videoUrl} type="video/mp4" />
                  Votre navigateur ne supporte pas la lecture de vidéos.
                </video>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default VideoGallery;