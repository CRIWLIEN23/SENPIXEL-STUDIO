import React from 'react';
import { Menu, X } from 'lucide-react';

interface NavbarProps {
  isMenuOpen: boolean;
  setIsMenuOpen: (isOpen: boolean) => void;
}

const Navbar: React.FC<NavbarProps> = ({ isMenuOpen, setIsMenuOpen }) => {
  return (
    <nav className="fixed w-full bg-[#212121]/90 backdrop-blur-sm z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-20">
          <a href="#" className="flex items-center space-x-3">
            <img 
              src="https://imgur.com/BomfSGx.jpg" 
              alt="SenPixel Studio Logo" 
              className="h-12 w-12 object-contain"
            />
            <span className="text-2xl font-bold text-[#FFC107]">
              SENPIXEL STUDIO
            </span>
          </a>

          <div className="hidden md:flex space-x-8">
            <NavLink href="#about">À propos</NavLink>
            <NavLink href="#portfolio">Portfolio</NavLink>
            <NavLink href="#services">Services</NavLink>
            <NavLink href="#pricing">Tarifs</NavLink>
            <NavLink href="#testimonials">Témoignages</NavLink>
            <NavLink href="#contact">Contact</NavLink>
          </div>

          <button
            className="md:hidden text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-[#212121] border-t border-gray-800">
          <div className="container mx-auto px-4 py-4 space-y-4">
            <MobileNavLink href="#about" onClick={() => setIsMenuOpen(false)}>
              À propos
            </MobileNavLink>
            <MobileNavLink href="#portfolio" onClick={() => setIsMenuOpen(false)}>
              Portfolio
            </MobileNavLink>
            <MobileNavLink href="#services" onClick={() => setIsMenuOpen(false)}>
              Services
            </MobileNavLink>
            <MobileNavLink href="#pricing" onClick={() => setIsMenuOpen(false)}>
              Tarifs
            </MobileNavLink>
            <MobileNavLink href="#testimonials" onClick={() => setIsMenuOpen(false)}>
              Témoignages
            </MobileNavLink>
            <MobileNavLink href="#contact" onClick={() => setIsMenuOpen(false)}>
              Contact
            </MobileNavLink>
          </div>
        </div>
      )}
    </nav>
  );
};

const NavLink: React.FC<{ href: string; children: React.ReactNode }> = ({
  href,
  children,
}) => (
  <a
    href={href}
    className="text-white hover:text-[#FFC107] transition-colors duration-300"
  >
    {children}
  </a>
);

const MobileNavLink: React.FC<{
  href: string;
  onClick: () => void;
  children: React.ReactNode;
}> = ({ href, onClick, children }) => (
  <a
    href={href}
    className="block text-white hover:text-[#FFC107] transition-colors duration-300"
    onClick={onClick}
  >
    {children}
  </a>
);

export default Navbar;