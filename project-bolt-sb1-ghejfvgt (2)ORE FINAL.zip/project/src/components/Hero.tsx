import React, { useEffect, useState } from 'react';
import { Camera, Video, Volume2, VolumeX } from 'lucide-react';

const Hero = () => {
  const [text, setText] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [audio] = useState(new Audio('https://audio.jukehost.co.uk/TbluXA11aKtFOwaNlpUWkcHTyJm6PrIT'));
  const fullText = 'Capturons ensemble vos moments les plus précieux';
  
  useEffect(() => {
    let index = 0;
    const timer = setInterval(() => {
      if (index <= fullText.length) {
        setText(fullText.slice(0, index));
        index++;
      } else {
        clearInterval(timer);
      }
    }, 100);

    return () => {
      clearInterval(timer);
      audio.pause();
    };
  }, [audio]);

  const toggleAudio = () => {
    if (isPlaying) {
      audio.pause();
    } else {
      audio.play().catch(error => {
        console.error('Erreur lors de la lecture audio:', error);
      });
    }
    setIsPlaying(!isPlaying);
  };

  // Mettre à jour l'état isPlaying quand l'audio se termine
  useEffect(() => {
    const handleEnded = () => setIsPlaying(false);
    audio.addEventListener('ended', handleEnded);
    return () => audio.removeEventListener('ended', handleEnded);
  }, [audio]);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Logo Background */}
      <div className="absolute inset-0 w-full h-full">
        <div 
          className="absolute inset-0 w-full h-full bg-center bg-no-repeat bg-contain opacity-10 blur-md"
          style={{
            backgroundImage: 'url("https://imgur.com/BomfSGx.jpg")',
            transform: 'scale(1.1)'
          }}
        />
        <div className="absolute inset-0 bg-black/70" />
      </div>

      {/* Video Background */}
      <div className="absolute inset-0 w-full h-full">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover opacity-50"
        >
          <source
            src="https://player.vimeo.com/external/459863667.sd.mp4?s=e9e6b9a3b266c0a4e4cbc53f2c93f8f2f5d09b00&profile_id=164&oauth2_token_id=57447761"
            type="video/mp4"
          />
        </video>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4">
        <div className="flex justify-center mb-6">
          <img 
            src="https://imgur.com/BomfSGx.jpg" 
            alt="SenPixel Studio Logo" 
            className="h-24 w-24 object-contain"
          />
        </div>
        <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white">
          <span className="text-[#FFC107]">SENPIXEL</span> STUDIO
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-white h-8">
          {text}
          <span className="animate-blink">|</span>
        </p>
        <div className="flex flex-col md:flex-row gap-4 justify-center">
          <button 
            onClick={() => scrollToSection('services')}
            className="bg-[#007BFF] hover:bg-[#0056b3] text-white px-8 py-3 rounded-full flex items-center justify-center gap-2 transition-colors transform hover:scale-105 active:scale-95"
          >
            <Camera size={20} />
            Nos Services Photo
          </button>
          <button 
            onClick={() => scrollToSection('services')}
            className="bg-[#FF3D00] hover:bg-[#cc3100] text-white px-8 py-3 rounded-full flex items-center justify-center gap-2 transition-colors transform hover:scale-105 active:scale-95"
          >
            <Video size={20} />
            Nos Services Vidéo
          </button>
        </div>
      </div>

      {/* Audio Control Button */}
      <button
        onClick={toggleAudio}
        className="absolute top-24 right-4 z-20 bg-[#FFC107] hover:bg-[#e6ae06] text-[#212121] p-3 rounded-full transition-colors"
        title={isPlaying ? "Arrêter l'audio" : "Jouer l'audio"}
      >
        {isPlaying ? <VolumeX size={24} /> : <Volume2 size={24} />}
      </button>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-8 h-12 rounded-full border-2 border-white flex items-start justify-center p-2">
          <div className="w-1 h-3 bg-white rounded-full animate-scroll" />
        </div>
      </div>
    </div>
  );
};

export default Hero;