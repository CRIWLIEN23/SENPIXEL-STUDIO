import React from 'react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-[#1a1a1a]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
          <span className="text-[#FFC107]">À propos</span> de nous
        </h2>
        <div className="max-w-4xl mx-auto text-gray-300">
          <p className="mb-6">
            SENPIXEL STUDIO est un studio de photographie et de vidéographie créatif basé à Tambacounda, 
            au cœur du Sénégal. Notre passion est de capturer les moments précieux et de raconter des 
            histoires visuelles uniques.
          </p>
          <p className="mb-6">
            Notre équipe de professionnels talentueux combine expertise technique et vision artistique 
            pour créer des contenus visuels exceptionnels qui dépassent les attentes de nos clients.
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;