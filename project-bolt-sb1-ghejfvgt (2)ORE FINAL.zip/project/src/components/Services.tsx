import React from 'react';
import { Camera, Video, Users, Building2 } from 'lucide-react';

const Services = () => {
  return (
    <section id="services" className="py-20 bg-[#1a1a1a]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
          <span className="text-[#FFC107]">Nos</span> Services
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <ServiceCard 
            icon={<Camera className="w-8 h-8 text-[#FFC107]" />}
            title="Photographie"
            description="Séances photo professionnelles pour tous vos événements"
          />
          <ServiceCard 
            icon={<Video className="w-8 h-8 text-[#007BFF]" />}
            title="Vidéographie"
            description="Production vidéo de haute qualité pour vos projets"
          />
          <ServiceCard 
            icon={<Users className="w-8 h-8 text-[#FF3D00]" />}
            title="Événementiel"
            description="Couverture complète de vos événements spéciaux"
          />
          <ServiceCard 
            icon={<Building2 className="w-8 h-8 text-[#FFC107]" />}
            title="Corporate"
            description="Services photo et vidéo pour entreprises"
          />
        </div>
      </div>
    </section>
  );
};

const ServiceCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => (
  <div className="bg-[#212121] p-6 rounded-lg transition-transform duration-300 hover:-translate-y-2">
    <div className="mb-4">{icon}</div>
    <h3 className="text-xl font-semibold mb-2 text-white">{title}</h3>
    <p className="text-gray-400">{description}</p>
  </div>
);

export default Services;