import React, { useState } from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const mailtoLink = `mailto:SENPIXELSTUDIO@GMAIL.COM,CRIWLIEN19@GMAIL.COM?subject=Message de ${formData.name}&body=De: ${formData.name}%0D%0AEmail: ${formData.email}%0D%0A%0D%0AMessage:%0D%0A${formData.message}`;
    
    window.location.href = mailtoLink;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="contact" className="py-20 bg-[#1a1a1a]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
          <span className="text-[#FFC107]">Contactez</span> Nous
        </h2>
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <h3 className="text-xl font-semibold mb-6 text-white">Informations de contact</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3 text-gray-300">
                <Phone className="text-[#FFC107]" />
                <span>+221 78 293 14 68/78 384 91 97</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <Mail className="text-[#FFC107]" />
                <span>SENPIXELSTUDIO@GMAIL.COM</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <MapPin className="text-[#FFC107]" />
                <span>Tambacounda, Sénégal</span>
              </div>
            </div>
          </div>
          <div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <input
                  type="text"
                  name="name"
                  placeholder="Votre nom"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full p-3 bg-[#212121] rounded-lg border border-gray-700 focus:border-[#FFC107] focus:outline-none text-white"
                  required
                />
              </div>
              <div>
                <input
                  type="email"
                  name="email"
                  placeholder="Votre email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full p-3 bg-[#212121] rounded-lg border border-gray-700 focus:border-[#FFC107] focus:outline-none text-white"
                  required
                />
              </div>
              <div>
                <textarea
                  name="message"
                  placeholder="Votre message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="w-full p-3 bg-[#212121] rounded-lg border border-gray-700 focus:border-[#FFC107] focus:outline-none text-white"
                  required
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full bg-[#FFC107] text-[#212121] font-semibold py-3 px-6 rounded-lg hover:bg-[#e6ae06] transition-colors"
              >
                Envoyer le message
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;