import React, { useRef, useEffect } from 'react';

const Portfolio = () => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const scrollContainer = scrollRef.current;
    if (!scrollContainer) return;

    const scroll = () => {
      scrollContainer.scrollLeft += 1;
      if (scrollContainer.scrollLeft >= scrollContainer.scrollWidth - scrollContainer.clientWidth) {
        scrollContainer.scrollLeft = 0;
      }
    };

    const interval = setInterval(scroll, 30);
    return () => clearInterval(interval);
  }, []);

  const images = [
    "https://images.unsplash.com/photo-1542038784456-1ea8e935640e",
    "https://images.unsplash.com/photo-1493863641943-9b68992a8d07",
    "https://images.unsplash.com/photo-1516035069371-29a1b244cc32",
    "https://images.unsplash.com/photo-1554048612-b6a482bc67e5",
    "https://images.unsplash.com/photo-1682687220742-aba13b6e50ba",
    "https://images.unsplash.com/photo-1537633552985-df8429e8048b",
    "https://images.unsplash.com/photo-1504593811423-6dd665756598",
    "https://images.unsplash.com/photo-1519741497674-611481863552",
    "https://images.unsplash.com/photo-1519225421980-715cb0215aed",
    "https://images.unsplash.com/photo-1532712938310-34cb3982ef74"
  ];

  return (
    <section id="portfolio" className="py-20 bg-[#212121]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
          <span className="text-[#FFC107]">Notre</span> Portfolio
        </h2>
        
        {/* Grid Portfolio */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          <div className="relative group overflow-hidden rounded-lg aspect-[4/3]">
            <img 
              src="https://imgur.com/a9dtp5m.jpg" 
              alt="Portfolio 1" 
              className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
            />
          </div>
          <div className="relative group overflow-hidden rounded-lg aspect-[4/3]">
            <img 
              src="https://imgur.com/AlqOuKr.jpg" 
              alt="Portfolio 2" 
              className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
            />
          </div>
          <div className="relative group overflow-hidden rounded-lg aspect-[4/3]">
            <img 
              src="https://imgur.com/VeKXTDL.jpg" 
              alt="Portfolio 3" 
              className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
            />
          </div>
          <div className="relative group overflow-hidden rounded-lg aspect-[4/3]">
            <img 
              src="https://images.unsplash.com/photo-1537633552985-df8429e8048b" 
              alt="Portfolio 4" 
              className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
            />
          </div>
          <div className="relative group overflow-hidden rounded-lg aspect-[4/3]">
            <img 
              src="https://images.unsplash.com/photo-1504593811423-6dd665756598" 
              alt="Portfolio 5" 
              className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
            />
          </div>
          <div className="relative group overflow-hidden rounded-lg aspect-[4/3]">
            <img 
              src="https://images.unsplash.com/photo-1519741497674-611481863552" 
              alt="Portfolio 6" 
              className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
            />
          </div>
        </div>

        {/* Horizontal Scrolling Gallery */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold text-center mb-8">
            <span className="text-[#FFC107]">Galerie</span> Défilante
          </h3>
          <div 
            ref={scrollRef}
            className="flex overflow-x-hidden gap-4 py-4 relative"
            style={{ scrollBehavior: 'smooth' }}
          >
            {[...images, ...images].map((src, index) => (
              <div
                key={index}
                className="flex-none w-[300px] aspect-[3/2] overflow-hidden rounded-lg"
              >
                <img
                  src={src}
                  alt={`Gallery ${index + 1}`}
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                  loading="lazy"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;