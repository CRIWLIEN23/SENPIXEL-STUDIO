export interface User {
  id: string;
  email: string;
  full_name: string;
  avatar_url?: string;
}

export interface Booking {
  id: string;
  user_id: string;
  service_type: 'photo' | 'video' | 'event';
  date: string;
  time: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  notes?: string;
}

export interface Gallery {
  id: string;
  title: string;
  description?: string;
  category: 'wedding' | 'corporate' | 'event' | 'portrait';
  image_url: string;
  created_at: string;
}

export interface BlogPost {
  id: string;
  title: string;
  content: string;
  image_url?: string;
  author: string;
  created_at: string;
  category: 'tips' | 'news' | 'behind-the-scenes';
}

export interface Testimonial {
  id: string;
  user_name: string;
  role: string;
  content: string;
  rating: number;
  image_url?: string;
  created_at: string;
}