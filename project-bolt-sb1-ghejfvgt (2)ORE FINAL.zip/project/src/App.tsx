import React from 'react';
import { Menu, X, Camera, Video, ChevronDown, Instagram, Facebook, Twitter } from 'lucide-react';
import { useState } from 'react';
import Hero from './components/Hero';
import About from './components/About';
import Portfolio from './components/Portfolio';
import Services from './components/Services';
import Pricing from './components/Pricing';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Navbar from './components/Navbar';
import VideoGallery from './components/VideoGallery';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#212121] text-white">
      <Navbar isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />
      
      <main>
        <Hero />
        <About />
        <Portfolio />
        <VideoGallery />
        <Services />
        <Pricing />
        <Testimonials />
        <Contact />
      </main>

      <footer className="bg-[#212121] py-8 border-t border-gray-800">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="text-2xl font-bold text-[#FFC107]">SENPIXEL STUDIO</h3>
              <p className="text-gray-400">Tambacounda, Sénégal</p>
            </div>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-[#FFC107] transition-colors">
                <Instagram size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#FFC107] transition-colors">
                <Facebook size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#FFC107] transition-colors">
                <Twitter size={24} />
              </a>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} SENPIXEL STUDIO. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App